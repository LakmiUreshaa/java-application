/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_hotel_system;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Lonovo
 */

public class RESERVATION {
    // in the reservation table we need to add two foriegn keys
    // 1 for the client
    // -> ALTER TABLE reservations ADD CONSTRAINT fk_client_id FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE CASCADE
    // 2 for the room
    // -> ALTER TABLE reservations ADD CONSTRAINT fk_room_number FOREIGN KEY(room_number) REFERENCES rooms(r_number) ON DELETE CASCADE
    // add another foreign key between table types and rooms
    
    
    // / some fixes we need to do
    // 1-when we add a new reservation the room associated with this it should be set to reserved = yes 
     // and when deleting the reservation it should be set to reserved = no
     // 2-when we add a new reservation we need to check if the room is already reserved
     // 3- check if the date in > the current date
     // 4- check if the date out > the date in
     
    
           MY_CONNECTION my_connection = new MY_CONNECTION();
           ROOMS room = new ROOMS();
    // create a functinto add a new reservation
           public boolean addReservation (int client_id, int room_number, String dateIn , String dateOut ){
          PreparedStatement ps;
          ResultSet rs;
          String addQuery = "INSERT INTO `reservations`( `client_id`, `room_number`, `date_in`, `date_out`) VALUES (?,?,?,?)";
          
           try {
               ps = my_connection.createConnection().prepareStatement(addQuery);
               ps.setInt(1,client_id);
           // the reserved column will be set to no
           // the reserved column mean in this room is free or not
               ps.setInt(2,room_number);
               ps.setString(3,dateIn);
               ps.setString(4,dateOut);
           // when we add a new room
               
           if (room.isRoomReserved(room_number).equals("No"))
           {
               if(ps.executeUpdate()>0) {
              room.setRoomToReserved(room_number, "yes");
              return true;
              }
              else{
              return false;
              }
           }
           else
           {
               JOptionPane.showMessageDialog(null,"This Room is lready Reserved", "Room Reserved", JOptionPane.WARNING_MESSAGE);
            
               return false;
           }
          
           }
           
            catch (SQLException ex) {
               Logger.getLogger(CLIENT.class.getName()).log(Level.SEVERE, null, ex);
                    return false;
}
           }

          public boolean EditReservation(int reservation_id, int client_id, int room_number, String dateIn , String dateOut){
        
        PreparedStatement ps;
          ResultSet rs;
          String editQuery = "UPDATE `reservations` SET `client_id`=?,`room_number`=?,`date_in`=?,`date_out`=? WHERE `id`=?";
          
           try {
               ps = my_connection.createConnection().prepareStatement(editQuery);
                
                ps.setInt(1,client_id);
                ps.setInt(2,room_number);
                ps.setString(3,dateIn);
                ps.setString(4,dateOut);
                ps.setInt(5,reservation_id);
               
               return (ps.executeUpdate()>0);
               
           }
           
            catch (SQLException ex) {
               Logger.getLogger(CLIENT.class.getName()).log(Level.SEVERE, null, ex);
                    return false;
           }
    }

         public boolean RemoveReservation (int reservation_id){
         PreparedStatement ps;
          ResultSet rs;
          String deleteQuery = "DELETE FROM `reservations` WHERE `id`=?";
          
           try {
               ps = my_connection.createConnection().prepareStatement(deleteQuery);
               
               ps.setInt(1, reservation_id);
               
               // we need to get room number before deleting the reservation
               int room_number = getRoomNumberFromReservation(reservation_id);
            
               if(ps.executeUpdate()>0) {
              room.setRoomToReserved(room_number, "No");
              return true;
          }
          else{
              return false;
          }
               
           }
           
            catch (SQLException ex) {
               Logger.getLogger(CLIENT.class.getName()).log(Level.SEVERE, null, ex);
                    return false;
           }
}
         
        public void fillReservationsJTable(JTable table)
         {
          PreparedStatement ps;
          ResultSet rs;
          String selectQuery = "SELECT * FROM `reservations`";
          
           try {
               ps = my_connection.createConnection().prepareStatement(selectQuery);
               rs = ps.executeQuery();
               DefaultTableModel tableModel = (DefaultTableModel)table.getModel();
               
               Object[] row;
               while(rs.next()){
                   row = new Object[5];
                   row[0] = rs.getInt(1);
                   row[1] = rs.getInt(2);
                   row[2] = rs.getInt(3);
                   row[3] = rs.getString(4);
                   row[4] = rs.getString(5);
                   
                   tableModel.addRow(row);
                   
               }
                       
           } catch (SQLException ex) {
               Logger.getLogger(CLIENT.class.getName()).log(Level.SEVERE, null, ex);
           }
      }
    
    
// create a function to get the room number frm a reservation
        public int getRoomNumberFromReservation(int reservationID){
             PreparedStatement ps;
          ResultSet rs;
          String selectQuery = "SELECT 'room_number' FROM `reservations` WHERE 'id'=?";
          
           try {
               ps = my_connection.createConnection().prepareStatement(selectQuery);
               
               ps.setInt(1, reservationID);
               rs = ps.executeQuery();
               
               
              if(rs.next()){
                  return rs.getInt(1);
              }
              else{
                  return 0;
              }
            
            
        }
           catch (SQLException ex) {
               Logger.getLogger(CLIENT.class.getName()).log(Level.SEVERE, null, ex);
           }
           return 0;
        }

}


